from distutils.core import setup

setup(name="Stuff",
version = "1.0",
packages = ['stuff'],
scripts = ['test.py']
)
